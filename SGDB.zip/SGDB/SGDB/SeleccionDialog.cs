﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SGDB
{
    public partial class SeleccionDialog : Form
    {
        public SeleccionDialog()
        {
            InitializeComponent();
        }

        private void BtTabla_Click(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, EventArgs e)
        {

        }

        private void BtIndice_Click(object sender, EventArgs e)
        {

        }

        private void BtTrigger_Click(object sender, EventArgs e)
        {

        }

        private void BtView_Click(object sender, EventArgs e)
        {

        }
    }
}
